<footer>
    <div class="container">
        <p>&copy; <?php echo date('Y'); ?> <?php echo esc_html(get_theme_mod('hero_title', 'Joseph Young')); ?>. All rights reserved.</p>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
